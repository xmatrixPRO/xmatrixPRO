import React from "react";

export default function Modal() {
    return (
        <div style={{position: "fixed"}} className="modal fade" role="dialog" id="thanks">
            <div className="modal-dialog"></div>

            <div className="thanks_block">
                <div className="close" data-dismiss="modal">
                    <i className='bx bx-x'></i>
                </div>
                <div className="thanks_block_title">
                    <h4>Thank You!</h4>
                </div>

                <div className="token_address_block">
                    {/*<textarea id="to-copy">123456789123456789123456</textarea>*/}
                    <button id="copy" className="copy_button" type="button">Copy <span className="copiedtext"
                                                                                       aria-hidden="true">Copied</span>
                    </button>
                </div>

            </div>

        </div>
    );
}