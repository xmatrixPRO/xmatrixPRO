import React from "react";
import {useWeb3React} from "@web3-react/core";
import {useEagerConnect, useICO, useBUSD, useInactiveListener} from "./hooks";
import {injected} from "./connectors";
import {formatUnits, parseUnits} from "@ethersproject/units";
import {BigNumber} from "ethers";
import Modal from "react-modal";

const shortenAddress = (address) => address.substr(0, 15) + "..." + address.substr(-15);

function BuyTokens() {
    const triedEager = useEagerConnect();
    const { chainId, active, activate, library } = useWeb3React();
    const ico = useICO();
    const busdContract = useBUSD();
    useInactiveListener(!triedEager);

    const [price, setPrice] = React.useState(null);
    const [token, setToken] = React.useState(null);

    React.useEffect(() => {
        if (ico) {
            ico.price().then(r => setPrice(r));
            ico.token().then(t => setToken(t));
        }
    }, [ico]);

    const [busd, setBusd] = React.useState("");
    const [matrix, setMatrix] = React.useState("");
    const [stage, setStage] = React.useState(0);

    const onChangeBusd = (value) => {
        setBusd(value);
        setStage(0);

        try {
            const intValue = parseUnits(value);
            if (intValue && price) {
                setMatrix(formatUnits(intValue.mul(price).div(BigNumber.from(10).pow(18))));
            }
        } catch(e) {}
    };

    const onChangeMatrix = (value) => {
        setMatrix(value);
        setStage(0);

        try {
            const intValue = parseUnits(value);
            if (intValue && price) {
                setBusd(formatUnits(intValue.mul(BigNumber.from(10).pow(18)).div(price)));
            }
        } catch(e) {}
    }

    const expectedChainId = Number.parseInt(process.env.REACT_APP_CHAIN_ID);

    let onClickConnect = null;
    let connectText = "Connected";
    if (!active) {
        onClickConnect = () => activate(injected);
        connectText = "Connect Wallet";
    } else if (chainId !== expectedChainId) {
        onClickConnect = () => library.provider.request({
            method: "wallet_switchEthereumChain",
            params: [{chainId: expectedChainId.toString(16)}]
        });
        connectText = "Switch to BSC";
    }

    let onClickBuy = null;
    let buyText = "Approve";
    if (stage === 1) {
        buyText = "Waiting...";
    } else if (stage === 2) {
        buyText = "Buy";
    }
    if (active && chainId === expectedChainId && ico && busdContract && busd) {
        if (stage === 0) {
            onClickBuy = () => {
                try {
                    const intValue = parseUnits(busd);
                    busdContract.approve(ico.address, intValue).then(tx => {
                        setStage(1);
                        tx.wait().then(() => {
                            setStage(2);
                        })
                    });
                } catch(e) {}
            }
        } else if (stage === 2) {
            onClickBuy = () => {
                try {
                    const intValue = parseUnits(busd);
                    ico.buy(intValue).then(tx => {
                        setStage(1);
                        tx.wait().then(() => {
                            setStage(0);
                            setIsOpen(true);
                            console.log("Purchased");
                        })
                    });
                } catch(e) {}
            }
        }
    }

    const [modalIsOpen, setIsOpen] = React.useState(false);

    const customStyles = {
        content: {
            top: '50%',
            left: '50%',
            right: 'auto',
            bottom: 'auto',
            marginRight: '-50%',
            transform: 'translate(-50%, -50%)',
            width: "500px",
            height: "150px",
            backgroundColor: "transparent",
            border: "none"
        },
        overlay: {zIndex: 1000}
    };

    // Make sure to bind modal to your appElement (https://reactcommunity.org/react-modal/accessibility/)
    Modal.setAppElement('#buyTokens');

    return (
        <React.Fragment>

            <div className="fourth_buy_inputs">

                <div className="buy_tokens__input_form">
                    <div className="buy_tokens__input_box">
                        <p className="buy_tokens__input_title">Enter the amount of money</p>
                        <input type="number" className="buy_tokens__input" placeholder="$1"
                               value={busd} onChange={(e) => onChangeBusd(e.target.value)} />

                            <div className="error_min_buy_block">
                                <span>Min. Buy: 5 BUSD</span>
                            </div>

                    </div>
                    <div className="buy_tokens__input_box">
                        <p className="buy_tokens__input_title">You will receive</p>
                        <input type="number" className="buy_tokens__input" placeholder="25"
                               value={matrix} onChange={(e) => onChangeMatrix(e.target.value)} />
                    </div>
                </div>

                <div className="tokens_currency__form">
                    <div className="tokens_currency__input_box">
                        <p className="tokens_currency__title">Usdt</p>
                        <input type="number" disabled className="tokens_currency__input" placeholder="BUSD" />
                    </div>
                    <div className="tokens_currency__input_box">
                        <p className="buy_tokens__input_title">Token</p>
                        <input type="number" disabled className="tokens_currency__input" placeholder="TOKEN" />
                    </div>
                </div>

                <div className="fourth_brick">
                    <div>
                        <ul className="fourth_brick_ul">
                            <li>Note:</li>
                            <li>40% lock</li>
                            <li>2 months</li>
                        </ul>
                    </div>
                </div>

            </div>

            <div className="fourth_buy_buttons">
                <div>
                    <div className="buy_button">
                        <a className="connect_wallet_btn" onClick={onClickConnect}>
                            {connectText}
                        </a>
                    </div>
                    <div className="buy_button">
                        <a className="buy_token_btn"  onClick={onClickBuy}>
                            {buyText}
                        </a>
                    </div>
                </div>
            </div>

            <Modal
                isOpen={modalIsOpen}
                onRequestClose={() => setIsOpen(false)}
                style={customStyles}
                contentLabel="Example Modal"
            >
                <div className="thanks_block" style={{width: "100%", height: "100%", margin: 0, paddingTop: 20}}>
                    <div className="close" data-dismiss="modal">
                        <i className='bx bx-x' onClick={() => setIsOpen(false)}></i>
                    </div>
                    <div className="thanks_block_title">
                        <h4>Thank You!</h4>
                    </div>

                    <div className="token_address_block">
                        <textarea id="to-copy">{token ? shortenAddress(token) : null}</textarea>
                        <button id="copy" className="copy_button"
                                onClick={() => navigator.clipboard.writeText(token)}
                        >
                            Copy <span className="copiedtext" aria-hidden="true">Copied</span>
                        </button>
                    </div>
                </div>
            </Modal>

        </React.Fragment>
    );
}

// data-toggle="modal" data-target="#thanks"

export default BuyTokens;
