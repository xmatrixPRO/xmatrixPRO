import { InjectedConnector } from '@web3-react/injected-connector';

export const CHAIN_ID = Number.parseInt(process.env.REACT_APP_CHAIN_ID);

export const injected = new InjectedConnector({ });